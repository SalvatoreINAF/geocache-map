#*******************************************************************************
# E.S.O. - VLT project
#
# "@(#) $Id: sxmoapdTat.tcl 297901 2017-05-26 17:40:15Z dricci $"
#
# who       when      what
# --------  --------  ----------------------------------------------
# alongino  24/08/04  created
#
#************************************************************************

global env

# To avoid interactive GUIs e.g. from templates
set env(TAT_TEST) TRUE

# Make sure that the right reference files for the specified TARGET are used
if {[ info exists env(TARGET) ]} {
    set reffiles [glob -nocomplain ref/$env(TARGET)/*]
    foreach reffile $reffiles {
        exec cp -f $reffile ref
    }
}

# _o0o_
